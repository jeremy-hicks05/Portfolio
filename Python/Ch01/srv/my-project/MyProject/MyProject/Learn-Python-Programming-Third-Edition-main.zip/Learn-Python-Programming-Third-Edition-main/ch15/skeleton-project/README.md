# Simple skeleton project

This is a skeleton of a project that you can copy and flesh out to create your own project.
