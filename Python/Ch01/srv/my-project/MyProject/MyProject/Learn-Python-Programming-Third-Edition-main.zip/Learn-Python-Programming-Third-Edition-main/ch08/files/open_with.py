# files/open_with.py
with open('fear.txt') as fh:
    for line in fh:
        print(line.strip())
