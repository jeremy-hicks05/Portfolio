# apic/rails/apps.py
from django.apps import AppConfig


class RailsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "rails"
