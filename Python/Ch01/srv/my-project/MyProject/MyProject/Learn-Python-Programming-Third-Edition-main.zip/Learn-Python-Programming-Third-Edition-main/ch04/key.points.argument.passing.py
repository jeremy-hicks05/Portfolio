# key.points.argument.passing.py
x = 3
def func(y):
    print(y)

func(x)  # prints: 3
